# Food Access Research Atlas, San Diego County


The Food Access Research Atlas:

* Presents a spatial overview of food access indicators for low-income and other census tracts using different measures of supermarket accessibility;
* Provides food access data for populations within census tracts; and
* Offers census-tract-level data on food access that can be downloaded for community planning or research purposes.

This version of the Atlas dataset has only tracts in San Diego couny, and tract identifiers have been converted from Tiger format Geoids to ACS format. 
 
## What can you do with the Atlas?

* Create maps showing food access indicators by census tract using different measures and indicators of supermarket accessibility;
* Compare food access measures based on 2015 data with the previous 2010 measures;
* View indicators of food access for selected subpopulations; and
* Download census-tract-level data on food access measures.

# Processing Notes

While the URL for the source file is available online, this data package is produced from the CSV file saved from the Excel source, because large Excel files are very slow to load and process. The file's source URL is included in the References section of the metadata. 